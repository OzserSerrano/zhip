#' @title zhipxn
#'
#' @description Función que calcula z para prueba de hipótesis de media muestral o distribucion normal muestral.
#'
#' @param x Valor de la media muestral
#'
#' @param U Valor de la media poblacional
#'
#' @param S Valor de la desviacion
#'
#' @param n Valor de la muestra (n->30)
#'
#' @return Valor z correspondiente a x
#' @export
#'
#' @examples zhipxn(75.5,72,12,36)
#' @examples zhipxn(x=75.5,U=72,S=12,n=36)
#' @examples zhipxn(x,U,S,n) Valores definidos previamente
zhipxn<-function(x,U,S,n) {(x-U)/(S/(sqrt(n)))}
