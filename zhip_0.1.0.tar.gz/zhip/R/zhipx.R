#' @title zhipx
#'
#' @description Función que calcula z para prueba de hipótesis de media poblacional o distribucion normal.
#'
#' @param x Valor de la media muestral
#'
#' @param U Valor de la media poblacional
#'
#' @param S Valor de la desviacion
#'
#' @return Valor z correspondiente a x
#' @export
#'
#' @examples zhipx(75.5,72,12)
#' @examples zhipx(x=75.5,U=72,S=12)
#' @examples zhipx(x,U,S,n) Valores definidos previamente
zhipx<-function(x,U,S) {(x-U)/S}
