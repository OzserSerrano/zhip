#' @title zhipprop
#'
#' @description Función que calcula z para prueba de hipótesis de media muestral o distribucion normal muestral.
#'
#' @param p Valor de la proporcion Muestral
#'
#' @param P Valor de la proporcion Poblacional
#'
#' @param Q Valor de la no ocurrencia del evento (1-P)
#'
#' @param n Valor de la muestra
#'
#' @return Valor z correspondiente a p
#' @export
#'
#' @examples zhipprop(15/100,0.10,0.90,100)
#' @examples zhipprop(p=15/100,P=0.10,Q=0.90,n=100)
#' @examples zhipprop(p=0.15,P=0.10,Q=0.90,n=100)
#' @examples zhipprop(p,P,Q,n) Valores definidos previamente
zhipprop<-function(p,P,Q,n) {(p-P)/(sqrt((P*Q)/n))}
